/*******************************************************************************
  MPLAB Harmony Application Source File
  
  Company:
    Microchip Technology Inc.
  
  File Name:
    uart_streamer.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It 
    implements the logic of the application's state machine and it may call 
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Included Files 
// *****************************************************************************
// *****************************************************************************

#include "uart_streamer.h"

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
/* Application Data

  Summary:
    Holds application data

  Description:
    This structure holds the application's data.

  Remarks:
    This structure should be initialized by the APP_Initialize function.
    
    Application strings and buffers are be defined outside this structure.
*/

UART_STREAMER_DATA USdata;

// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Functions
// *****************************************************************************
// *****************************************************************************

/* TODO:  Add any necessary callback funtions.
*/

// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************

/* TODO:  Add any necessary local functions.
*/


// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void UART_STREAMER_Initialize ( void )

  Remarks:
    See prototype in uart_streamer.h.
 */

void UART_STREAMER_Initialize ( void )
{
    /* Place the App state machine in its initial state. */
    USdata.state = UART_STREAMER_STATE_INIT;
    USdata.toggle = 0;
    
    USdata.navSendQ = xQueueCreate( 10, sizeof( char ) );
    if( USdata.navSendQ == 0 )
    {
        // Queue was not created and must not be used.
        USdata.state = UART_STREAMER_STATE_ERROR;
    }
}


/******************************************************************************
  Function:
    void UART_STREAMER_Tasks ( void )

  Remarks:
    See prototype in uart_streamer.h.
 */

void UART_STREAMER_Tasks ( void )
{
    /* Check the application's current state. */
    switch ( USdata.state )
    {
        /* Application's initial state. */
        case UART_STREAMER_STATE_INIT:
        {
            USdata.state = UART_STREAMER_STATE_WAIT;
            break;
        }
        
        case UART_STREAMER_STATE_WAIT:
        {
            char data;
            if( USdata.navSendQ != 0 )
            {   
                // Receive a message on the created queue.  Block until data available
                if( xQueueReceive( USdata.navSendQ, &( data ), portMAX_DELAY ) )
                {
                    //PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, PORTS_BIT_POS_13, 1);
                }
            }
            USdata.state = UART_STREAMER_STATE_TX;
            break;
        }
        
        case UART_STREAMER_STATE_TX:
        {
            USdata.state = UART_STREAMER_STATE_WAIT;

            char buffer[55];
            const char *dataString;
            sprintf(buffer,"%d,   %d,   %d \n",(int16_t)USdata.uartData.accel[0]
                                              ,(int16_t)USdata.uartData.accel[1]
                                              ,(int16_t)USdata.uartData.accel[2]);
            USdata.stringPointer = &(buffer[0]);
            
            while(!UART_WriteString());
            
            USdata.state = UART_STREAMER_STATE_WAIT;            
            break;
        }

        case UART_STREAMER_STATE_ERROR:
        {
            break;
        }

        /* The default state should never be executed. */
        default:
        {
            USdata.state = UART_STREAMER_STATE_ERROR;
            break;
        }
    }
}

void sendToNavSendQ(char data)
{
    xQueueSendToBack(USdata.navSendQ, &data, portMAX_DELAY);
}

void UART_STREAMER_Receive_Struct ( UART_Streamer_t *data )
{
    //memcpy(&USdata.uartData, &data, sizeof (UART_Streamer_t));
    USdata.uartData.accel[0] = data->accel[0];
    USdata.uartData.accel[1] = data->accel[1];
    USdata.uartData.accel[2] = data->accel[2];
}

bool UART_WriteString(void)
{
    if(*USdata.stringPointer == '\0')
    {
        return true;
    }

    /* Write a character at a time, only if transmitter is empty */
    while (PLIB_USART_TransmitterIsEmpty(USART_ID_1))
    {
        /* Send character */
        PLIB_USART_TransmitterByteSend(USART_ID_1, *USdata.stringPointer);

        /* Increment to address of next character */
        USdata.stringPointer++;

        if(*USdata.stringPointer == '\0')
        {
            return true;
        }
    }
    return false;
}
/*******************************************************************************
 End of File
 */
