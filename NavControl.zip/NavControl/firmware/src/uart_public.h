/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.h

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

#ifndef _UART_PUBLIC_H    /* Guard against multiple inclusion */
#define _UART_PUBLIC_H


/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */
/* ************************************************************************** */

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include "peripheral/ports/plib_ports.h"
#include "peripheral/int/plib_int.h"
#include "navigation_public.h"

/* Provide C++ Compatibility */
#ifdef __cplusplus
extern "C" {
#endif

const char *stringPointer;

typedef struct
{
    uint16_t accel[3];
    unsigned int distTraveled;
    unsigned int distRemaining;
    double zVelMPS;
    
    NAV_STATES state;
    bool errorFlag; 
    bool cgtValveOpen;
} UART_Streamer_t;

//bool WriteString(void);


    /* Provide C++ Compatibility */
#ifdef __cplusplus
}
#endif

#endif /* _EXAMPLE_FILE_NAME_H */

/* *****************************************************************************
 End of File
 */
