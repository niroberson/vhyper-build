/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.h

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

#ifndef _NAVIGATION_PUBLIC_H    /* Guard against multiple inclusion */
#define _NAVIGATION_PUBLIC_H


/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */
/* ************************************************************************** */

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include "peripheral/ports/plib_ports.h"
#include "peripheral/oc/plib_oc.h"

/* Provide C++ Compatibility */
#ifdef __cplusplus
extern "C" {
#endif
    
typedef enum
{
	/* Application's state machine's initial state. */
	NAV_STATE_INIT=0,
    NAV_STATE_SERVICE=1,
    NAV_STATE_IDLE=2,
    NAV_STATE_STAGE_ONE_PROP=3,
    NAV_STATE_STAGE_TWO_PROP=4,
    NAV_STATE_BRAKE=5,
    NAV_STATE_ERROR=6,
    NAV_STATE_EMERGENCY=7,
            
} NAV_STATES;

    /* Provide C++ Compatibility */
#ifdef __cplusplus
}
#endif

#endif /* _EXAMPLE_FILE_NAME_H */

/* *****************************************************************************
 End of File
 */
