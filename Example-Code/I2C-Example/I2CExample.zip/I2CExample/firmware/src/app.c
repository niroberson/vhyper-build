/*******************************************************************************
  MPLAB Harmony Application Source File
  
  Company:
    Microchip Technology Inc.
  
  File Name:
    app.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It 
    implements the logic of the application's state machine and it may call 
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Included Files 
// *****************************************************************************
// *****************************************************************************

#include "app.h"

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
/* Application Data

  Summary:
    Holds application data

  Description:
    This structure holds the application's data.

  Remarks:
    This structure should be initialized by the APP_Initialize function.
    
    Application strings and buffers are be defined outside this structure.
*/

APP_DATA appData;

// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Functions
// *****************************************************************************
// *****************************************************************************

/* TODO:  Add any necessary callback funtions.
*/

// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************

/* TODO:  Add any necessary local functions.
*/


// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void APP_Initialize ( void )

  Remarks:
    See prototype in app.h.
 */

void APP_Initialize ( void )
{
    /* Place the App state machine in its initial state. */
    appData.state = APP_STATE_INIT;
    
    /* TODO: Initialize your application's state machine and other
     * parameters.
     */
    appData.slaveAddress = 0x28 << 1;
}


/******************************************************************************
  Function:
    void APP_Tasks ( void )

  Remarks:
    See prototype in app.h.
 */

void APP_Tasks ( void )
{
    /* Check the application's current state. */
    switch ( appData.state )
    {
        /* Application's initial state. */
        case APP_STATE_INIT:
        {
            appData.state = APP_STATE_RUN;
            
            // Sets up the i2c bus to be read/write and nonblocking.
            appData.i2c1Handle = DRV_I2C_Open(DRV_I2C_INDEX_0, 
                DRV_IO_INTENT_READ | 
                DRV_IO_INTENT_WRITE | 
                DRV_IO_INTENT_NONBLOCKING);
            
            /* Optional setup for callback function. You can either send the 
             * stop and restart commands from this function, or you can edit the
             * driver. I recommend editing the driver, because it doesn't run 
             * into issues with task switching. */
            DRV_I2C_BufferEventHandlerSet(appData.i2c1Handle, 
                I2C1_Callback, NULL);         
            
            break;
        }

        /* TODO: implement your application state machine.*/
        case APP_STATE_RUN:
        {
            appData.state = APP_STATE_RUN;
            /* Writes dataBuffer to the slave over the i2c bus. The while loop 
             * reads the buffer status for i2c bus to wait until the data has
             * finished being sent. */  
            uint8_t dataBuffer[] = {0x00, 0x00};
            appData.i2cBufferHandle = DRV_I2C_BufferAddWrite(appData.i2c1Handle, 
                &(appData.slaveAddress), 
                &(dataBuffer), 
                sizeof(dataBuffer), 
                NULL);
            while(!(DRV_I2C_BufferStatus(appData.i2cBufferHandle) == 
                DRV_I2C_BUFFER_EVENT_COMPLETE));
            
            
            /* Reads data from the slave and stores in readBuffer. In this case
             * it will read 2 bytes. The while loop then waits until the i2c
             * bus is no longer busy. */
            uint8_t readBuffer[2];
            appData.i2cBufferHandle = DRV_I2C_BufferAddRead(appData.i2c1Handle, 
                &(appData.slaveAddress), 
                &(readBuffer[0]), 
                sizeof(readBuffer), 
                NULL);
            while(!(DRV_I2C_BufferStatus(appData.i2cBufferHandle) == 
                DRV_I2C_BUFFER_EVENT_COMPLETE ));
        }
        
        case APP_STATE_IDLE:
        {
            // Does nothing
        }
        
        /* The default state should never be executed. */
        default:
        {
            /* TODO: Handle error in application's state machine. */
            break;
        }
    }
}
 
void I2C1_Callback(DRV_I2C_BUFFER_EVENT event, DRV_I2C_BUFFER_HANDLE handle, 
    uintptr_t context)
{
    switch(event)
    {
        case DRV_I2C_SEND_STOP_EVENT:
        {
            DRV_I2C_StopEventSend(appData.i2c1Handle);
            break;
        }
        case DRV_I2C_SEND_RESTART_EVENT:
        {
            DRV_I2C_RestartEventSend(appData.i2c1Handle);           
            break;
        }
        case DRV_I2C_BUFFER_EVENT_COMPLETE:  
        {
            break;
        }
        case DRV_I2C_BUFFER_EVENT_ERROR:
        {
            break;
        }
        default:
        {
            break;         
        }
    }
}

/*******************************************************************************
 End of File
 */
