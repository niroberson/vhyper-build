/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.h

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

#ifndef _PHOTOELECTRIC_H    /* Guard against multiple inclusion */
#define _PHOTOELECTRIC_H


/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */
/* ************************************************************************** */

/* This section lists the other files that are included in this file.
 */

#include "navigation_public.h"

/* Provide C++ Compatibility */
#ifdef __cplusplus
extern "C" {
#endif
    
#define DELTA_X 100 // Distance between optical markings (ft.)

typedef struct
{  
    bool thousandFeetFlag;
    bool fivehundredFeetFlag;
    bool countFiveStrips;
    bool countTenStrips;
    bool underFastMarker;
    bool uartThousandFeet;
    bool uartHundredFeet;
    unsigned int fiveStripsCounter;
    unsigned int tenStripsCounter;
    
    unsigned long recentMillisPassed;
    unsigned long t[2];
    int deltaT[2];
    double seconds;
    
    double zVelocity[2]; // ft/s
    double zVelMPS; // m/s
    double zAvgAccel; // m/s^2
    
    unsigned int distTraveled;
    unsigned int distRemaining;
  
} PHOTOELECTRIC_DATA;

void PHOTOELECTRIC_Init_Data(PHOTOELECTRIC_DATA *photoData);
void PHOTOELECTRIC_Service(PHOTOELECTRIC_DATA *photoData);

static void PHOTOELECTRIC_Under_Fast_Marker(PHOTOELECTRIC_DATA *photoData);
static void PHOTOELECTRIC_Not_Under_Fast_Marker(PHOTOELECTRIC_DATA *photoData);
static void PHOTOELECTRIC_Calc_Kinematics(PHOTOELECTRIC_DATA *photoData);

    /* Provide C++ Compatibility */
#ifdef __cplusplus
}
#endif

#endif /* _EXAMPLE_FILE_NAME_H */

/* *****************************************************************************
 End of File
 */
