/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.c

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */
/* ************************************************************************** */

/* This section lists the other files that are included in this file.
 */

#include "photoelectric.h"

void PHOTOELECTRIC_Init_Data(PHOTOELECTRIC_DATA *photoData)
{
    #if NAV_TESTING == 1
    /* MATLAB Digilent triggers interrupt when starting
       simulation, we want to ignore that */
    navData.startSim = false;
#endif
    
    /* Optical marking data */
    photoData->thousandFeetFlag = false;
    photoData->fivehundredFeetFlag = false;
    photoData->countFiveStrips = false;
    photoData->countTenStrips = false;
    photoData->fiveStripsCounter = 0;
    photoData->tenStripsCounter = 0;
    photoData->underFastMarker = false;

    /* Position detection */
    photoData->distRemaining = 5000;
    photoData->distTraveled = 0;
    
    /* Velocity detection */
    photoData->zAvgAccel = 0;
    photoData->zVelMPS = 0;
    photoData->zVelocity[0] = 0;
    photoData->zVelocity[1] = 0;
    
    /* Time data */
    photoData->deltaT[0] = 0;
    photoData->deltaT[1] = 0;
    photoData->t[0] = 0;
    photoData->t[1] = 0;
    photoData->seconds = 0;
    
    /* Uart Data */
    photoData->uartHundredFeet = false;
    photoData->uartThousandFeet = false;
}

void PHOTOELECTRIC_Service(PHOTOELECTRIC_DATA *photoData)
{
    //photoData->t[1] = photoData->millisPassed;
    photoData->deltaT[1] = photoData->t[1] - photoData->t[0];
    
    if(!photoData->underFastMarker)
    {
        PHOTOELECTRIC_Not_Under_Fast_Marker(photoData);
    }
    else if(photoData->underFastMarker)
    {
        PHOTOELECTRIC_Under_Fast_Marker(photoData);
    }
    else
    {
        // ERROR! Should not be here
    }
}

static void PHOTOELECTRIC_Under_Fast_Marker(PHOTOELECTRIC_DATA *photoData)
{
    /* If Under 1000ft. remaining markers */
    if(photoData->countTenStrips)
    {
        photoData->tenStripsCounter++;
        if(photoData->tenStripsCounter == 8)
        {
            photoData->underFastMarker = false;
            photoData->countTenStrips = false;
            photoData->thousandFeetFlag = true;
        }
    }
    // If under 500ft. remaining markers
    else if(photoData->countFiveStrips)
    {
        photoData->fiveStripsCounter++;
        if(photoData->fiveStripsCounter == 3)
        {
            photoData->underFastMarker = false;
            photoData->countFiveStrips = false;
            photoData->fivehundredFeetFlag = false;
        }
    }
    else
    {
        // ERROR! Should not be here
    }
}

static void PHOTOELECTRIC_Not_Under_Fast_Marker(PHOTOELECTRIC_DATA *photoData)
{
    // Check to see if at 1000ft remain. or 500ft. remaining markers
    if(photoData->deltaT[0] >= (100*photoData->deltaT[1]))
    {
        // We are under fast markers
        photoData->underFastMarker = true;
        
        // Were we already under 1000 ft. remaining markers?
        if(photoData->thousandFeetFlag)
        {
            photoData->uartHundredFeet = true;
            photoData->distRemaining = 500;
            photoData->fivehundredFeetFlag = true;
            photoData->thousandFeetFlag = false;
            photoData->countFiveStrips = true;
        }
        // If not than this is the first time this is being called so we are
        else
        {
            photoData->uartThousandFeet = true;
            photoData->distRemaining = 1000;
            photoData->thousandFeetFlag = true;
            photoData->countTenStrips = true;
        }
    }
    else
    {
        PHOTOELECTRIC_Calc_Kinematics(photoData);
    }
}

static void PHOTOELECTRIC_Calc_Kinematics(PHOTOELECTRIC_DATA *photoData)
{
    if(!photoData->underFastMarker)
    {
        /* Calculate Position Data */
        photoData->distTraveled = photoData->distTraveled + DELTA_X;
        photoData->distRemaining = photoData->distRemaining - DELTA_X;
        
        /* Calculate Velocity */
        double calc, calc1;
        photoData->seconds = photoData->deltaT[1]/(double)1000;
        calc = (double)(DELTA_X)/(photoData->seconds);
        calc1 = 2*calc;
        photoData->zVelocity[1] = calc1 - photoData->zVelocity[0]; // ft/s
        photoData->zVelMPS = photoData->zVelocity[1]/(double)3.2808399; // ft/s to m/s
        
        /* Calculate average acceleration */
        photoData->zAvgAccel = (photoData->zVelocity[1] - photoData->zVelocity[0])/photoData->seconds; // m/s^2
        photoData->zAvgAccel = photoData->zAvgAccel/(double)3.2808399; // m/s^2
    }
    else if(photoData->underFastMarker);
    
    else
    {
       /* ERROR! Should not be here */
       setNavState(NAV_STATE_ERROR);
    } 
    
    // Previous now equal to current
    // When underFastMarker == TRUE, [0] = [1] (No Change)
    photoData->t[0] = photoData->t[1];
    photoData->deltaT[0] = photoData->deltaT[1];
    photoData->zVelocity[0] = photoData->zVelocity[1];
}

/* *****************************************************************************
 End of File
 */
