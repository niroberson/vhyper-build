/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.c

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */
/* ************************************************************************** */

/* This section lists the other files that are included in this file.
 */

#include "adxl345.h"

ACCEL_DATA accelData;
range_t range;

int16_t ACCEL_Multi_Read(uint8_t addr)
{
    // Prepare address for reading
    addr = addr | 0x80;
    
    /* Writes dataBuffer to the slave over the i2c bus. The while loop 
    * reads the buffer status for i2c bus to wait until the data has
    * finished being sent. */    
    uint8_t dataBuffer[] = {addr};
    accelData.i2cBufferHandle = DRV_I2C_BufferAddWrite(accelData.i2c1Handle, 
        &(accelData.slaveAddressWrite), 
        &(dataBuffer), 
        sizeof(dataBuffer), 
        NULL);
    
    while(!(DRV_I2C_BufferStatus(accelData.i2cBufferHandle) == 
        DRV_I2C_BUFFER_EVENT_COMPLETE));
            
    /* Reads data from the slave and stores in readBuffer. In this case
     * it will read 2 bytes. The while loop then waits until the i2c
     * bus is no longer busy. */
    uint8_t readBuffer[2];
    accelData.i2cBufferHandle = DRV_I2C_BufferAddRead(accelData.i2c1Handle, 
        &(accelData.slaveAddressRead), 
        &(readBuffer[0]), 
        sizeof(readBuffer), 
        NULL);
    
    while(!(DRV_I2C_BufferStatus(accelData.i2cBufferHandle) == 
        DRV_I2C_BUFFER_EVENT_COMPLETE ));

    int16_t rawData;
    return rawData = (readBuffer[1]<<8) | readBuffer[0];
}

uint8_t ACCEL_Get_Byte(uint8_t addr)
{
    // Prepare address for reading
    addr = addr | 0x80;
    
    /* Writes dataBuffer to the slave over the i2c bus. The while loop 
    * reads the buffer status for i2c bus to wait until the data has
    * finished being sent. */  
    uint8_t dataBuffer[] = {addr};
    accelData.i2cBufferHandle = DRV_I2C_BufferAddWrite(accelData.i2c1Handle, 
        &(accelData.slaveAddressWrite), 
        &(dataBuffer), 
        sizeof(dataBuffer), 
        NULL);
    
    while(!(DRV_I2C_BufferStatus(accelData.i2cBufferHandle) == 
        DRV_I2C_BUFFER_EVENT_COMPLETE));
            
    /* Reads data from the slave and stores in readBuffer. In this case
     * it will read 2 bytes. The while loop then waits until the i2c
     * bus is no longer busy. */
    uint8_t readBuffer[1];
    accelData.i2cBufferHandle = DRV_I2C_BufferAddRead(accelData.i2c1Handle, 
        &(accelData.slaveAddressRead), 
        &(readBuffer[0]), 
        sizeof(readBuffer), 
        NULL);
    
    while(!(DRV_I2C_BufferStatus(accelData.i2cBufferHandle) == 
        DRV_I2C_BUFFER_EVENT_COMPLETE ));

    return readBuffer[0];
}

void ACCEL_Write_Byte(uint8_t addr, uint8_t data)
{
    /* Writes dataBuffer to the slave over the i2c bus. The while loop 
    * reads the buffer status for i2c bus to wait until the data has
    * finished being sent. */  
    uint8_t dataBuffer[] = {addr, data};
    accelData.i2cBufferHandle = DRV_I2C_BufferAddWrite(accelData.i2c1Handle, 
        &(accelData.slaveAddressWrite), 
        &(dataBuffer), 
        sizeof(dataBuffer), 
        NULL);
    
    while(!(DRV_I2C_BufferStatus(accelData.i2cBufferHandle) == 
        DRV_I2C_BUFFER_EVENT_COMPLETE));
}

void ACCEL_Init(void)
{
    // Write CS High, ALT Address Low (Header-JF) to enable I2C on the device
    // and to set the slave address of the accelerometer to be 0x53
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, PORTS_BIT_POS_12, 1);
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_F, PORTS_BIT_POS_4, 0);
    
    accelData.slaveAddressRead = 0xA7;
    accelData.slaveAddressWrite = 0xA6;
    
    accelData.i2c1Handle = DRV_I2C_Open(DRV_I2C_INDEX_0, 
                DRV_IO_INTENT_READ | 
                DRV_IO_INTENT_WRITE | 
                DRV_IO_INTENT_NONBLOCKING);
    
    DRV_I2C_BufferEventHandlerSet(accelData.i2c1Handle, 
                I2C1_Callback, NULL); 
    
    // Set range to +- 4g
    ACCEL_Set_Range(ADXL345_RANGE_16_G);
    
    // Set bandwidth to 100Hz
    ACCEL_Set_DataRate(ADXL345_DATARATE_100_HZ);
    
    // Set to measurement mode
    ACCEL_Write_Byte(ADXL345_REG_POWER_CTL, MEASURE);
}

int16_t ACCEL_Get_AccelX()
{
    /* Either DATAX0 or DATAY0 */
    return ACCEL_Multi_Read(ADXL345_REG_DATAX0);
}

int16_t ACCEL_Get_AccelY()
{
    /* Z axis on accelerometer corresponds to track Y axis */
    return ACCEL_Multi_Read(ADXL345_REG_DATAZ0);
}

int16_t ACCEL_Get_AccelZ()
{
    /* Either DATAX0 or DATAY0 */
    return ACCEL_Multi_Read(ADXL345_REG_DATAY0);
}

int16_t ACCEL_Get_VelX(ACCELEROMETER_DATA *accelData, int16_t accel)
{
    double deltaT;
    if((ACCEL_Get_DataRate()) == ADXL345_DATARATE_100_HZ)
        deltaT = 0.01;
    int16_t accelMPSS = (accel/(256))*9.81;
    return accelData->accelVelOld[0] + accelMPSS*deltaT;
}

int16_t ACCEL_Get_VelY(ACCELEROMETER_DATA *accelData, int16_t accel)
{
    double deltaT;
    if((ACCEL_Get_DataRate()) == ADXL345_DATARATE_100_HZ)
        deltaT = 0.01;
    int16_t accelMPSS = (accel/(256))*9.81;
    return accelData->accelVelOld[1] + accelMPSS*deltaT;
}

int16_t ACCEL_Get_VelZ(ACCELEROMETER_DATA *accelData, int16_t accel)
{
    double deltaT;
    if((ACCEL_Get_DataRate()) == ADXL345_DATARATE_100_HZ)
        deltaT = 0.01;
    int16_t accelMPSS = (accel/(256))*9.81;
    return accelData->accelVelOld[2] + accelMPSS*deltaT;
}

uint8_t ACCEL_Get_DeviceID(void)
{
    return ACCEL_Get_Byte(ADXL345_REG_DEVID);
}

void ACCEL_Set_Range(range_t range)
{
  /* Red the data format register to preserve bits */
  uint8_t format = ACCEL_Get_Byte(ADXL345_REG_DATA_FORMAT);

  /* Update the data rate */
  format &= ~0x0F;
  format |= range;
  
  /* Make sure that the FULL-RES bit is enabled for range scaling */
  format |= 0x08;
  
  /* Write the register back to the IC */
  ACCEL_Write_Byte(ADXL345_REG_DATA_FORMAT, format);
}

range_t ACCEL_Get_Range(void)
{
    return (range_t)(ACCEL_Get_Byte(ADXL345_REG_DATA_FORMAT) & 0x03);
}

void ACCEL_Set_DataRate(dataRate_t dataRate)
{
  /* Note: The LOW_POWER bits are currently ignored and we always keep
     the device in 'normal' mode */
  ACCEL_Write_Byte(ADXL345_REG_BW_RATE, dataRate);
}

dataRate_t ACCEL_Get_DataRate(void)
{
  return (dataRate_t)(ACCEL_Get_Byte(ADXL345_REG_BW_RATE) & 0x0F);
}

void ACCEL_Enable_Interrupts()
{   
    /* INT2 on PMOD -> JF-07
     * INT1 on PMOD -> JE-07 */
    
    /* Fist disable interrupts to avoid unwanted interrupt generation */
    ACCEL_Write_Byte(ADXL345_REG_INT_ENABLE, 0x00);
    
    /* Set register bits to 1 to correspond to INT2 on Accel */
    ACCEL_Write_Byte(ADXL345_REG_INT_MAP, 0x10);
    
    /* Set activity on certain axis to trigger interrupt 
     * D6 -> x-axis activity
     * D5 -> y-axis activity
     * D4 -> z-axis activity*/
    ACCEL_Write_Byte(ADXL345_REG_ACT_INACT_CTL, 0x40);
    
    /* Set the activity threshold to trigger interrupt on activity */
    ACCEL_Write_Byte(ADXL345_REG_THRESH_ACT, THRESH_ACT);
    
    /* Enable Interrupts on activity */
    ACCEL_Write_Byte(ADXL345_REG_INT_ENABLE, 0x10);
}

void ACCEL_Disable_Interrupts()
{
    /* Disable interrupts to avoid unwanted interrupt generation */
    ACCEL_Write_Byte(ADXL345_REG_INT_ENABLE, 0x00);
}

void ACCEL_Clear_Interrupt()
{
    /* Read this register to clear interrupts */
    uint8_t garbage = ACCEL_Get_Byte(ADXL345_REG_INT_SOURCE);
}

void ACCEL_Service(ACCELEROMETER_DATA *accelData)
{
    accelData->accel[0] = ACCEL_Get_AccelX();
    accelData->accel[1] = ACCEL_Get_AccelY();
    accelData->accel[2] = ACCEL_Get_AccelZ();
    
    accelData->accelVel[0] = ACCEL_Get_VelX(accelData,accelData->accel[0]);
    accelData->accelVel[1] = ACCEL_Get_VelX(accelData,accelData->accel[1]);
    accelData->accelVel[2] = ACCEL_Get_VelX(accelData,accelData->accel[2]);
    
    /* Save State */
    accelData->accelVelOld[0] = accelData->accelVel[0];
    accelData->accelVelOld[1] = accelData->accelVel[1];
    accelData->accelVelOld[2] = accelData->accelVel[2];
}

void I2C1_Callback(DRV_I2C_BUFFER_EVENT event, DRV_I2C_BUFFER_HANDLE handle, 
    uintptr_t context)
{
    switch(event)
    {
        case DRV_I2C_SEND_STOP_EVENT:
        {
            DRV_I2C_StopEventSend(accelData.i2c1Handle);
            break;
        }
        case DRV_I2C_SEND_RESTART_EVENT:
        {
            DRV_I2C_RestartEventSend(accelData.i2c1Handle);           
            break;
        }
        case DRV_I2C_BUFFER_EVENT_COMPLETE:  
        {
            break;
        }
        case DRV_I2C_BUFFER_EVENT_ERROR:
        {
            break;
        }
        default:
        {
            break;         
        }
    }
}
/* *****************************************************************************
 End of File
 */
