/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.c

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */
/* ************************************************************************** */

/* This section lists the other files that are included in this file.
 */

#include "control.h"

uint16_t PWM = 0;

void CNTRL_Service(char controlByte)
{   
    uint8_t devID = (controlByte & DEV_ID_BITS) >> 4;
  
    // Control Byte Parsing 
    if(devID == CNTRL_LOW_SPEED_MOTOR)
    {
        CNTRL_Low_Speed_Motor(controlByte);
    }
    
    else if(devID == CNTRL_EMERGENCY_BRAKES)
    {
       CNTRL_Emergency_Brakes(controlByte);
    }
    
    else if(devID == CNTRL_SET_STATE)
        CNTRL_Set_State(controlByte);
    
    else if(devID == CNTRL_LINEAR_ACTUATOR)
        CNTRL_Linear_Actuator(controlByte);
    
    else if(devID == CNTRL_CGT_VALVE)
        CNTRL_CGT_Valve(controlByte);
    
    else
        setNavState(NAV_STATE_ERROR);
}

/************************************/
/*      Low Speed Motor Control     */
/************************************/

static void CNTRL_Low_Speed_Motor(char data)
{
    uint8_t dataBits = data & DATA_BITS;
    
    if(dataBits == LSM_MOTOR_START);
        // Enable PWM
    else if(dataBits == LSM_MOTOR_STOP);
        // Disable PWM
    else if(dataBits == LSM_MOTOR_FORWARD);
        //PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, PORTS_BIT_POS_14, 1);
    else if(dataBits == LSM_MOTOR_REVERSE);
        //PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, PORTS_BIT_POS_15, 1);
}

static void CNTRL_Emergency_Brakes(char data)
{
    //PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, PORTS_BIT_POS_13, 1);
    uint8_t dataBits = data & DATA_BITS;
    
    if(dataBits == EBRAKE_ENGAGE);
        //PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, PORTS_BIT_POS_13, 1);
        // Digital write GPIO Low
    else if(dataBits == EBRAKE_RESET);
        // Digital write GPIO High
}

static void CNTRL_Magnetic_Brakes(char data)
{
    //PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, PORTS_BIT_POS_15, 1);
    //PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, PORTS_BIT_POS_14, 1);
}

/************************************/
/*           State Control          */
/************************************/

static void CNTRL_Set_State(char data)
{
    uint8_t dataBits = data & DATA_BITS;
    
    if(dataBits == STATE_INIT)
    {
        setNavState(NAV_STATE_INIT);
    }

    else if(dataBits == STATE_SERVICE)
    {   
        setNavState(NAV_STATE_SERVICE);
    }

    else if(dataBits == STATE_IDLE)
    {
        setNavState(NAV_STATE_IDLE);
        ACCEL_Enable_Interrupts();
    }
               
    else if(dataBits == STATE_ERROR)
    {
        setNavState(NAV_STATE_ERROR);
    }
  
    else
        setNavState(NAV_STATE_ERROR);
}

/************************************/
/*       Accelerometer Control      */
/************************************/

static void CNTRL_Accelerometer(char data)
{
    uint8_t dataBits = data & DATA_BITS;
    
    if(dataBits == ACCEL_CLEAR_INTERRUPTS)
        ACCEL_Clear_Interrupt();
    
    else if(dataBits == ACCEL_ENABLE_INTERRUPTS)
        ACCEL_Enable_Interrupts();
    
    else if(dataBits == ACCEL_DISABLE_INTERRUPTS)
        ACCEL_Disable_Interrupts();
}

/************************************/
/*       CGT Control Functions      */
/************************************/

static void CNTRL_CGT_Valve(char data)
{
    uint8_t dataBits = data & DATA_BITS;
    
    if(dataBits == CGT_VALVE_OPEN)
        CNTRL_CGT_Valve_Open();
    
    else if(dataBits == CGT_VALVE_CLOSE)
        CNTRL_CGT_Valve_Close();

}

void CNTRL_CGT_Valve_Open()
{
    /* Set valve GPIO high */
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, PORTS_BIT_POS_14, 1);
}

void CNTRL_CGT_Valve_Close()
{
    /* Set valve GPIO low */
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, PORTS_BIT_POS_15, 1);
}


/************************************/
/*    Actuator Control Functions    */
/************************************/

static void CNTRL_Linear_Actuator(char data)
{
    uint8_t dataBits = data & DATA_BITS;
    
    if(dataBits == ACTUATOR_FORWARD)
        CNTRL_Actuator_Forward();
    
    else if(dataBits == ACTUATOR_REVERSE)
        CNTRL_Actuator_Reverse();
    
    else if(dataBits == ACTUATOR_INCREMENT_FORCE)
    {
        PWM+=40000;
        CNTRL_Actuator_Speed(PWM);
    }
    
    else if(dataBits == ACTUATOR_DECREMENT_FORCE)
    {
        PWM-=40000;
        CNTRL_Actuator_Speed(PWM);
    }
    
    else if(dataBits == ACTUATOR_OFF)
    {
        CNTRL_Actuator_Off();
    }
        //CNTRL_Actuator_Speed()
}

void CNTRL_Actuator_Forward()
{
    /* GPIO 1 HIGH */
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_C, PORTS_BIT_POS_4, 1);
    /* GPIO 2 LOW  */
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, PORTS_BIT_POS_10, 0);
}

void CNTRL_Actuator_Reverse()
{
    /* GPIO 1 HIGH */
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_C, PORTS_BIT_POS_4, 0);
    /* GPIO 2 LOW  */
    PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_D, PORTS_BIT_POS_10, 1);
}

void CNTRL_Actuator_Speed(uint16_t pwm)
{
    PLIB_OC_PulseWidth16BitSet(OC_ID_2, pwm);
}

void CNTRL_Actuator_Off()
{
    PLIB_OC_PulseWidth16BitSet(OC_ID_2, 0);
}

/* *****************************************************************************
 End of File
 */
