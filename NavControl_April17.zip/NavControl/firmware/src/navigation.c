/*******************************************************************************
  MPLAB Harmony Application Source File
  
  Company:
    Microchip Technology Inc.
  
  File Name:
    app.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It 
    implements the logic of the application's state machine and it may call 
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Included Files 
// *****************************************************************************
// *****************************************************************************

#include "navigation.h"

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
/* Application Data

  Summary:
    Holds application data

  Description:
    This structure holds the application's data.

  Remarks:
    This structure should be initialized by the APP_Initialize function.
    
    Application strings and buffers are be defined outside this structure.
*/

NAV_DATA navData;

// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

void NAVIGATION_Initialize ( void )
{
    /* Place the App state machine in its initial state. */
    navData.state = NAV_STATE_INIT;
    
    navData.errorFlag = false;
    navData.pusherConnected = true;
    navData.controlByte = 0;
    navData.millisPassed = 0;
    navData.accelCounter = 0;
    navData.cgtValveOpen = false;
    
    initPhotoData();
    
    // Create a queue capable of containing 10 unsigned long values.
    navData.navRecvQ = xQueueCreate( 200, sizeof( NAV_RECV_UNBLOCK ) );
    if( navData.navRecvQ == 0 )
    {
        // Queue was not created and must not be used.
        navData.state = NAV_STATE_ERROR;
        navData.errorFlag = true;
    }
}

void NAVIGATION_Tasks ( void )
{
    /* Check the application's current state. */
    switch ( navData.state )
    {
        /* Application's initial state. */
        case NAV_STATE_INIT:
        {
            navData.state = NAV_STATE_SERVICE;
            DRV_TMR0_Start();
            
            ACCEL_Init();
            if(ACCEL_Get_DeviceID() != ADXL345_DEV_ID)
                navData.state = NAV_STATE_ERROR;
           
            ACCEL_Disable_Interrupts();
            
            /* Clear the queue */
            NAV_RECV_UNBLOCK data;
            if( xQueueReceive( navData.navRecvQ,  &( data ), 0x08 ) )
            break;
        }
        
        case NAV_STATE_SERVICE:
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, PORTS_BIT_POS_12, 1);
            navData.state = NAV_STATE_SERVICE;
            
            NAV_RECV_UNBLOCK data;
            if( navData.navRecvQ != 0 )
            {
                // Receive a message on the created queue.  Block until data available
                if( xQueueReceive( navData.navRecvQ,  &( data ), portMAX_DELAY ) )
                {
                    /* Unblocking from UART RX */
                    if(data == NAV_RECV_UART_RX)
                    {
                        CNTRL_Service(navData.controlByte);
                    }
                    
                    /* Unblocking from Accelerometer update */
                    else if(data == NAV_RECV_ACCEL_UPDATE)
                    {   
                        ACCEL_Service(&navData.uartData);

                        char buffer[55];
                        const char *dataString;
                        sprintf(buffer,"\naccelZ: %d \r\n",(int16_t)navData.uartData.accel[2]);
                        navData.stringPointer = &(buffer[0]);
                        //while(!WriteStringNew());
                    }
                    
                    /* Unblocking from accelerometer interrupt */
                    else if(data == NAV_RECV_ACCEL_THRESH)
                    {
                        /* This shouldn't happen */
                        navData.uartData.errorFlag = true;
                        navData.state = NAV_STATE_ERROR;
                    }
                    
                    /* Unblocking from photoelectric interrupt */
                    else if(data == NAV_RECV_PHOTOELECTRIC)
                    {
                        /* This shouldn't happen */
                        navData.uartData.errorFlag = true;
                        //navData.state = NAV_STATE_ERROR; 
                    }
                    
                    /* Unblocking from pusher detach interrupt */
                    else if(data == NAV_RECV_PUSHER_DETACH)
                    {
                        /* This shouldn't happen */
                        navData.uartData.errorFlag = true;
                        //navData.state = NAV_STATE_ERROR;
                    }

                    else
                    {
                        navData.uartData.errorFlag = true;
                        navData.state = NAV_STATE_ERROR;
                    }     
                }
            }
            
            /* Prepare UART_Streamer with data to send */
            navData.uartData.state = navData.state;
            navData.uartData.errorFlag = navData.errorFlag;
            navData.uartData.zVelMPS = navData.photoData.zVelMPS;
            navData.uartData.distRemaining = navData.photoData.distRemaining;
            navData.uartData.distTraveled = navData.photoData.distTraveled;
            
            UART_STREAMER_Receive_Struct(&navData.uartData);
            
            /* Unblock UART_Streamer */
            sendToNavSendQ(0x01);
            
            break;
        }
        
        case NAV_STATE_IDLE:
        {
            navData.state = NAV_STATE_IDLE;

            NAV_RECV_UNBLOCK data;
            if( navData.navRecvQ != 0 )
            {
                // Receive a message on the created queue.  Block until data available
                if( xQueueReceive( navData.navRecvQ,  &( data ), portMAX_DELAY ) )
                {
                    /* Unblocking from UART RX */
                    if(data == NAV_RECV_UART_RX)
                    {
                        CNTRL_Service(navData.controlByte);
                    }
                    
                    /* Unblocking from accelerometer interrupt */
                    else if(data == NAV_RECV_ACCEL_THRESH)
                    {
                        PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, PORTS_BIT_POS_14, 1);
                        ACCEL_Clear_Interrupt();
                        ACCEL_Disable_Interrupts();
                        navData.startTimer = true;
                        navData.state = NAV_STATE_STAGE_ONE_PROP;
                    }
                    
                    /* Unblocking from photoelectric interrupt */
                    else if(data == NAV_RECV_PHOTOELECTRIC)
                    {
                        /* This shouldn't happen */
                        navData.uartData.errorFlag = true;
                        navData.state = NAV_STATE_ERROR; 
                    }
                    
                    /* Unblock from accelerometer update */
                    else if(data == NAV_RECV_ACCEL_UPDATE)
                    {
                        ACCEL_Service(&navData.uartData);
                    }
                    
                    /* Unblocking from pusher detach interrupt */
                    else if(data == NAV_RECV_PUSHER_DETACH)
                    {
                        /* This shouldn't happen */
                        navData.uartData.errorFlag = true;
                        navData.state = NAV_STATE_ERROR;
                    }
                }
            } 
            
            /* Prepare UART_Streamer with data to send */
            UART_STREAMER_Receive_Struct(&navData.uartData);
            
            /* Unblock UART_Streamer */
            sendToNavSendQ(0x01);
            
            break;
        }
        
        case NAV_STATE_STAGE_ONE_PROP:
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, PORTS_BIT_POS_15, 0);
            navData.state = NAV_STATE_STAGE_ONE_PROP;
            
            NAV_RECV_UNBLOCK data;
            if( navData.navRecvQ != 0 )
            {
                // Receive a message on the created queue.  Block until data available
                if( xQueueReceive( navData.navRecvQ,  &( data ), portMAX_DELAY ) )
                {
                    // If unblocking from UART RX
                    if(data == NAV_RECV_UART_RX)
                        CNTRL_Service(navData.controlByte);
                    
                    // Unblocking from Accelerometer update
                    else if(data == NAV_RECV_ACCEL_UPDATE)
                    {
                        ACCEL_Service(&navData.uartData);
                    }
                    
                    // Unblocking from photoelectric interrupt
                    else if(data == NAV_RECV_PHOTOELECTRIC)
                    {
                        PHOTOELECTRIC_Service(&navData.photoData); 
                    }
                    
                    /* Unblocking from pusher detach interrupt */
                    else if(data == NAV_RECV_PUSHER_DETACH)
                    {
                        // disable interrupts
                        navData.state = NAV_STATE_STAGE_TWO_PROP;
                        navData.cgtValveOpen = true;
                        CNTRL_CGT_Valve_Open();
                    }
                    
                    /* Unblocking from accelerometer interrupt */
                    else if(data == NAV_RECV_ACCEL_THRESH)
                    {
                        navData.state = NAV_STATE_ERROR;
                    }
                        
                    else
                        navData.state = NAV_STATE_ERROR;
                }
            }
            
            /* Prepare UART_Streamer with data to send */
            UART_STREAMER_Receive_Struct(&navData.uartData);
            
            /* Unblock UART_Streamer */
            sendToNavSendQ(0x01);
            
            break;
        }
        
        case NAV_STATE_STAGE_TWO_PROP:
        {
            navData.state = NAV_STATE_STAGE_TWO_PROP;
            
            NAV_RECV_UNBLOCK data;
            if( navData.navRecvQ != 0 )
            {
                /* Receive a message on the created queue.  Block until data available */
                if( xQueueReceive( navData.navRecvQ,  &( data ), portMAX_DELAY ) )
                {
                    /* If unblocking from UART RX */
                    if(data == NAV_RECV_UART_RX)
                    {
                        CNTRL_Service(navData.controlByte);
                    }
                    
                    /* Unblocking from Accelerometer update */
                    else if(data == NAV_RECV_ACCEL_UPDATE)
                    {
                        ACCEL_Service(&navData.uartData);
                    }
                    
                    /* Unblocking from photoelectric interrupt */
                    else if(data == NAV_RECV_PHOTOELECTRIC)
                    {
                        PHOTOELECTRIC_Service(&navData.photoData); 
                        if(navData.photoData.distRemaining == 2000)
                            navData.state = NAV_STATE_BRAKE;
                    }
                    
                    /* Unblocking from pusher detach interrupt */
                    else if(data == NAV_RECV_PUSHER_DETACH)
                    {
                        /* This shouldn't happen */
                        navData.state = NAV_STATE_ERROR;
                    }
                    
                    /* Unblocking from accelerometer interrupt */
                    else if(data == NAV_RECV_ACCEL_THRESH)
                    {
                        //navData.state = NAV_STATE_ERROR;
                    }
                        
                    else
                        navData.state = NAV_STATE_ERROR;
                }
            }
            
            if(navData.photoData.distRemaining == 2000)
            {
                navData.state = NAV_STATE_BRAKE;
                navData.uartData.state = NAV_STATE_BRAKE;
            }
            /* Prepare UART_Streamer with data to send */
            UART_STREAMER_Receive_Struct(&navData.uartData);
            
            /* Unblock UART_Streamer */
            sendToNavSendQ(0x01);
            
            break;
        }
        
        case NAV_STATE_BRAKE:
        {
            break;
        }
        
        case NAV_STATE_ERROR:
        {
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, PORTS_BIT_POS_12, 1);
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, PORTS_BIT_POS_13, 1);
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, PORTS_BIT_POS_14, 1);
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, PORTS_BIT_POS_15, 1);
            vTaskDelay(1000 / portTICK_PERIOD_MS);
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, PORTS_BIT_POS_12, 0);
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, PORTS_BIT_POS_13, 0);
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, PORTS_BIT_POS_14, 0);
            PLIB_PORTS_PinWrite(PORTS_ID_0, PORT_CHANNEL_G, PORTS_BIT_POS_15, 0);
            vTaskDelay(1000 / portTICK_PERIOD_MS);
            break;
        }
        
        case NAV_STATE_EMERGENCY:
        {
            break;
        }
        
        /* The default state should never be executed. */
        default:
        {
            navData.state = NAV_STATE_ERROR;
            break;
        }
    }
}

void sendToNavRecvQ(NAV_RECV_UNBLOCK data, BaseType_t* pxHigherPriorityTaskWoken)
{
    xQueueSendToBackFromISR(navData.navRecvQ, &data, pxHigherPriorityTaskWoken);
}

void sendToNavRecvQFront(NAV_RECV_UNBLOCK data, BaseType_t* pxHigherPriorityTaskWoken)
{
    xQueueOverwriteFromISR(navData.navRecvQ, &data, pxHigherPriorityTaskWoken);
    xQueueSendToBackFromISR(navData.navRecvQ, &data, pxHigherPriorityTaskWoken);
}

void millis()
{    
    if(navData.startTimer)
    {
        navData.millisCounter++;
    
        if(navData.millisCounter == MILLIS_OVERFLOW)
        {
            navData.millisPassed++;
            navData.millisCounter = 0;
        }
    }
}

bool accelUpdate(void)
{
    navData.accelCounter++;
    if(navData.accelCounter >= ACCEL_OVERFLOW)
    {
        navData.accelCounter = 0;
        return true;
    }
    else
        return false;
}

void saveByte(char data)
{
    navData.controlByte = data;
}

void saveCurrentMillis()
{
    navData.photoData.t[1] = navData.millisPassed;
}

void setNavState(NAV_STATES state)
{  
    switch ( state )
    {
        case NAV_STATE_INIT:
        {
            navData.state = NAV_STATE_INIT;
            break;
        }
        
        case NAV_STATE_SERVICE:
        {
            navData.state = NAV_STATE_SERVICE;
            break;
        }
        
        case NAV_STATE_IDLE:
        {
            navData.state = NAV_STATE_IDLE;
            break;
        }
        
        case NAV_STATE_STAGE_ONE_PROP:
        {
            navData.state = NAV_STATE_STAGE_ONE_PROP;
            break;
        }
        
        case NAV_STATE_STAGE_TWO_PROP:
        {
            navData.state = NAV_STATE_STAGE_TWO_PROP;
            break;
        }
        
        case NAV_STATE_BRAKE:
        {
            navData.state = NAV_STATE_BRAKE;
            break;
        }
        
        case NAV_STATE_ERROR:
        {
            navData.state = NAV_STATE_ERROR;
            break;
        }
        
        case NAV_STATE_EMERGENCY:
        {
            navData.state = NAV_STATE_EMERGENCY;
            break;
        }
    }  
}

void initPhotoData()
{
    /* Optical marking data */
    navData.photoData.thousandFeetFlag = false;
    navData.photoData.fivehundredFeetFlag = false;
    navData.photoData.countFiveStrips = false;
    navData.photoData.countTenStrips = false;
    navData.photoData.fiveStripsCounter = 0;
    navData.photoData.tenStripsCounter = 0;
    navData.photoData.underFastMarker = false;

    /* Position detection */
    navData.photoData.distRemaining = 5300;
    navData.photoData.distTraveled = 0;
    
    
    navData.photoData.zAvgAccel = 0;
    navData.photoData.zVelMPS = 0;
    navData.photoData.zVelocity[0] = 0;
    navData.photoData.zVelocity[1] = 0;
    
    navData.photoData.deltaT[0] = 0;
    navData.photoData.deltaT[1] = 0;
    navData.photoData.t[0] = 0;
    navData.photoData.t[1] = 0;
}

bool WriteStringNew(void)
{
    if(navData.stringPointer == '\0')
    {
        return true;
    }

    /* Write a character at a time, only if transmitter is empty */
    while (PLIB_USART_TransmitterIsEmpty(USART_ID_1))
    {
        /* Send character */
        PLIB_USART_TransmitterByteSend(USART_ID_1, *navData.stringPointer);

        /* Increment to address of next character */
        navData.stringPointer++;

        if(*navData.stringPointer == '\0')
        {
            return true;
        }
    }
    return false;
}

/*******************************************************************************
 End of File
 */

