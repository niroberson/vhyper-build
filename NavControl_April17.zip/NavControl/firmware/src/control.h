/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.h

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

#ifndef _CONTROL_H    /* Guard against multiple inclusion */
#define _CONTROL_H


/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */
/* ************************************************************************** */

/* This section lists the other files that are included in this file.
 */

//#include "navigation.h"
#include "navigation_public.h"
#include "adxl345.h"


/* Provide C++ Compatibility */
#ifdef __cplusplus
extern "C" {
#endif

#define DEV_ID_BITS 0xE0
#define DATA_BITS   0x1F
   
/* Device ID's */
typedef enum
{
    CNTRL_LOW_SPEED_MOTOR   = 0b000,
    CNTRL_EMERGENCY_BRAKES  = 0b001,
    CNTRL_MAGNETIC_BRAKES   = 0b010,
    CNTRL_ACCELEROMETER     = 0b011,
    CNTRL_SET_STATE         = 0b100,
 
} devID_t;

/* Low Speed motor control data*/
typedef enum
{
    LSM_MOTOR_FORWARD   = 0b00000,
    LSM_MOTOR_REVERSE   = 0b00001,
    LSM_MOTOR_STOP      = 0b00010,
    LSM_SPEED_INCREASE  = 0b00011,
    LSM_SPEED_DECREASE  = 0b00100,
    LSM_MOTOR_START     = 0b00101,
 
} LSM_Data;

/* Emergency brake control data */
typedef enum
{
    EBRAKE_ENGAGE   = 0b00000,
    EBRAKE_RESET    = 0b00001,
            
} EBRAKE_Data;

/* Accelerometer data */
typedef enum
{
    ACCEL_CLEAR_INTERRUPTS      = 0b00000,
    ACCEL_ENABLE_INTERRUPTS     = 0b00001,
    ACCEL_DISABLE_INTERRUPTS    = 0b00010,
    ACCEL_CALIBRATE             = 0b00011,
    ACCEL_START_MEASURING       = 0b00100,
            
} ACCEL_Data;

/* Setting start data */
typedef enum
{
    STATE_INIT              = 0b00000,
    STATE_SERVICE           = 0b00001,
    STATE_IDLE              = 0b00010,
    STATE_STAGE_ONE_PROP    = 0b00011,
    STATE_STAGE_TWO_PROP    = 0b00100,
    STATE_BRAKE             = 0b00101,
    STATE_EMERGENCY         = 0b00110,
    STATE_ERROR             = 0b00111,
            
} STATE_Data;


void CNTRL_Service(char controlByte);
static void CNTRL_Emergency_Brakes(char data);
static void CNTRL_Magnetic_Brakes(char data);
static void CNTRL_Low_Speed_Motor(char data);
static void CNTRL_Set_State(char data);
static void CNTRL_Accelerometer(char data);
void CNTRL_CGT_Valve_Open();
void CNTRL_CGT_Valve_Close();



    /* Provide C++ Compatibility */
#ifdef __cplusplus
}
#endif

#endif /* _EXAMPLE_FILE_NAME_H */

/* *****************************************************************************
 End of File
 */
