/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.h

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

#ifndef _ADXL345_H    /* Guard against multiple inclusion */
#define _ADXL345_H

/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */
/* ************************************************************************** */

/* This section lists the other files that are included in this file.
 */

//#include "navigation.h"
#include "navigation_public.h"
#include "../framework/driver/i2c/drv_i2c.h"
#include "uart_public.h"


/* Provide C++ Compatibility */
#ifdef __cplusplus
extern "C" {
#endif
    
 //   TODO: CALIBRATION METHOD
    
/*=========================================================================
    I2C ADDRESS/BITS
-----------------------------------------------------------------------*/

#define ADXL345_ADDRESS                 (0x53)    // Assumes ALT address pin low

/*=========================================================================*/
    
    
/*=========================================================================
    REGISTERS
-----------------------------------------------------------------------*/
#define ADXL345_REG_DEVID               (0x00)    // Device ID
#define ADXL345_REG_THRESH_TAP          (0x1D)    // Tap threshold
#define ADXL345_REG_OFSX                (0x1E)    // X-axis offset
#define ADXL345_REG_OFSY                (0x1F)    // Y-axis offset
#define ADXL345_REG_OFSZ                (0x20)    // Z-axis offset
#define ADXL345_REG_DUR                 (0x21)    // Tap duration
#define ADXL345_REG_LATENT              (0x22)    // Tap latency
#define ADXL345_REG_WINDOW              (0x23)    // Tap window
#define ADXL345_REG_THRESH_ACT          (0x24)    // Activity threshold
#define ADXL345_REG_THRESH_INACT        (0x25)    // Inactivity threshold
#define ADXL345_REG_TIME_INACT          (0x26)    // Inactivity time
#define ADXL345_REG_ACT_INACT_CTL       (0x27)    // Axis enable control for activity and inactivity detection
#define ADXL345_REG_THRESH_FF           (0x28)    // Free-fall threshold
#define ADXL345_REG_TIME_FF             (0x29)    // Free-fall time
#define ADXL345_REG_TAP_AXES            (0x2A)    // Axis control for single/double tap
#define ADXL345_REG_ACT_TAP_STATUS      (0x2B)    // Source for single/double tap
#define ADXL345_REG_BW_RATE             (0x2C)    // Data rate and power mode control
#define ADXL345_REG_POWER_CTL           (0x2D)    // Power-saving features control
#define ADXL345_REG_INT_ENABLE          (0x2E)    // Interrupt enable control
#define ADXL345_REG_INT_MAP             (0x2F)    // Interrupt mapping control
#define ADXL345_REG_INT_SOURCE          (0x30)    // Source of interrupts
#define ADXL345_REG_DATA_FORMAT         (0x31)    // Data format control
#define ADXL345_REG_DATAX0              (0x32)    // X-axis data 0
#define ADXL345_REG_DATAX1              (0x33)    // X-axis data 1
#define ADXL345_REG_DATAY0              (0x34)    // Y-axis data 0
#define ADXL345_REG_DATAY1              (0x35)    // Y-axis data 1
#define ADXL345_REG_DATAZ0              (0x36)    // Z-axis data 0
#define ADXL345_REG_DATAZ1              (0x37)    // Z-axis data 1
#define ADXL345_REG_FIFO_CTL            (0x38)    // FIFO control
#define ADXL345_REG_FIFO_STATUS         (0x39)    // FIFO status

/*=========================================================================*/
 
    
/*=========================================================================
    COMMON VALUES
-----------------------------------------------------------------------*/
    
#define MEASURE         0x08
#define ADXL345_DEV_ID  0xE5
    
/* Sets the value of activity threshold for interrupt triggering */
#define THRESH_ACT      0x11   

typedef struct
{
    uint8_t slaveAddressRead;
    uint8_t slaveAddressWrite;
    DRV_HANDLE i2c1Handle;
    DRV_I2C_BUFFER_HANDLE i2cBufferHandle;
    
} ACCEL_DATA;


/* Used with register 0x2C (ADXL345_REG_BW_RATE) to set bandwidth */
typedef enum
{
  ADXL345_DATARATE_3200_HZ    = 0b1111, // 1600Hz Bandwidth   140�A IDD
  ADXL345_DATARATE_1600_HZ    = 0b1110, //  800Hz Bandwidth    90�A IDD
  ADXL345_DATARATE_800_HZ     = 0b1101, //  400Hz Bandwidth   140�A IDD
  ADXL345_DATARATE_400_HZ     = 0b1100, //  200Hz Bandwidth   140�A IDD
  ADXL345_DATARATE_200_HZ     = 0b1011, //  100Hz Bandwidth   140�A IDD
  ADXL345_DATARATE_100_HZ     = 0b1010, //   50Hz Bandwidth   140�A IDD
  ADXL345_DATARATE_50_HZ      = 0b1001, //   25Hz Bandwidth    90�A IDD
  ADXL345_DATARATE_25_HZ      = 0b1000, // 12.5Hz Bandwidth    60�A IDD
  ADXL345_DATARATE_12_5_HZ    = 0b0111, // 6.25Hz Bandwidth    50�A IDD
  ADXL345_DATARATE_6_25HZ     = 0b0110, // 3.13Hz Bandwidth    45�A IDD
  ADXL345_DATARATE_3_13_HZ    = 0b0101, // 1.56Hz Bandwidth    40�A IDD
  ADXL345_DATARATE_1_56_HZ    = 0b0100, // 0.78Hz Bandwidth    34�A IDD
  ADXL345_DATARATE_0_78_HZ    = 0b0011, // 0.39Hz Bandwidth    23�A IDD
  ADXL345_DATARATE_0_39_HZ    = 0b0010, // 0.20Hz Bandwidth    23�A IDD
  ADXL345_DATARATE_0_20_HZ    = 0b0001, // 0.10Hz Bandwidth    23�A IDD
  ADXL345_DATARATE_0_10_HZ    = 0b0000  // 0.05Hz Bandwidth    23�A IDD (default value)
} dataRate_t;

/* Used with register 0x31 (ADXL345_REG_DATA_FORMAT) to set g range */
typedef enum
{
  ADXL345_RANGE_16_G          = 0b11,   // +/- 16g
  ADXL345_RANGE_8_G           = 0b10,   // +/- 8g
  ADXL345_RANGE_4_G           = 0b01,   // +/- 4g
  ADXL345_RANGE_2_G           = 0b00    // +/- 2g (default value)
} range_t;

void I2C1_Callback(DRV_I2C_BUFFER_EVENT event, DRV_I2C_BUFFER_HANDLE handle, 
    uintptr_t context);

int16_t ACCEL_Multi_Read(uint8_t addr);
uint8_t ACCEL_Get_Byte(uint8_t addr);
void ACCEL_Write_Byte(uint8_t addr, uint8_t data);

void ACCEL_Init(void);

uint8_t ACCEL_Get_DeviceID(void);

void ACCEL_Set_Range(range_t range);
range_t ACCEL_Get_Range(void);

void ACCEL_Enable_Interrupts(void);
void ACCEL_Disable_Interrupts(void);
void ACCEL_Clear_Interrupt(void);


void ACCEL_Set_DataRate(dataRate_t dataRate);
dataRate_t ACCEL_Get_DataRate(void);

int16_t ACCEL_Get_AccelX(void);
int16_t ACCEL_Get_AccelY(void);
int16_t ACCEL_Get_AccelZ(void);

int16_t ACCEL_Get_VelX(void);

void ACCEL_Service(UART_Streamer_t *uartData);

/* Provide C++ Compatibility */
#ifdef __cplusplus
}
#endif

#endif /* _EXAMPLE_FILE_NAME_H */

/* *****************************************************************************
 End of File
 */
